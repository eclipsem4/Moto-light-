# ShakeLight — Liquid Glass Shake-to-Flashlight App

ShakeLight lets users toggle their phone's hardware flashlight on or off with a physical shake gesture, operating reliably in the background, with the screen off, and across device reboots. The experience pairs a responsive sensor pipeline with a tactile, translucent Liquid Glass interface built on Material 3 and Android 12+ (`minSdk 31`) rendering capabilities.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural and UX choices incorporate your Phase 1 answers alongside platform requirements for modern Android (`minSdk 31`, `targetSdk 35`).

- **Confirmed Shake Gesture Default**: Uses a **Double-chop / shake** gesture with adjustable sensitivity (1–10) by default to prevent pocket false triggers, with an optional toggle in Settings to switch between Double-chop and Single sharp shake.
- **Confirmed Theme Posture**: **Follows the system Dark/Light theme** on first launch over an animated aurora glass backdrop, with an in-app appearance selector (System / Dark / Light) in Settings.
- **Confirmed Dependency Injection**: Uses **Hilt** (`SingletonComponent`, `ServiceComponent`, `@HiltViewModel`) for compile-time dependency injection across the background service, hardware controllers, DataStore repository, and Compose screens.
- **Confirmed First-Launch Flow**: Launches into a **3-screen Liquid Glass onboarding** sequence on first run to explain shake detection, flashlight/notification permissions, and battery optimization before entering the Home dashboard.
- **Foreground Service & SDK Alignment**: Sets `minSdk = 31` (enabling native `RenderEffect` / `Modifier.blur`, `VibratorManager`, and `TelephonyCallback` without legacy fallbacks) and `targetSdk = 35` (keeping `compileSdk` aligned with the project toolchain). Uses `foregroundServiceType="specialUse"` so background shake detection remains compliant with Android 14/15 `BOOT_COMPLETED` and lock-screen restrictions.

---

### 1. Overview & Core Concept

- **What It Does**: Monitors the device accelerometer inside a persistent, low-power foreground service to detect intentional shake gestures and toggle the rear camera LED flash via `CameraManager.setTorchMode()`, synchronized with system torch changes, call states, battery thresholds, and haptic feedback.
- **Target Audience & Context**: Everyday smartphone users needing instant, eyes-free flashlight access in dark environments, emergencies, or one-handed situations—even while the screen is locked or after a reboot.
- **Key Value**: Eliminates waking the phone, unlocking, or hunting for Quick Settings tiles while safeguarding battery life and preventing accidental pocket activations.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **First-Launch Onboarding (3 Glass Cards)**:
     - *Welcome & Gesture*: Introduces the double-chop/shake action with an interactive preview of the glowing torch orb.
     - *Essential Permissions*: Explains why Notification (`POST_NOTIFICATIONS`) and Camera (`CAMERA`) permissions are requested, with a one-tap grant trigger.
     - *Reliability & Battery*: Explains call-pause (`READ_PHONE_STATE`) and battery exemption options, then transitions to Home.
  2. **Home Dashboard**:
     - Displays an animated status pill (Listening / Paused for Call / Low Battery / Inactive) and torch hardware availability banner if no flash exists.
     - Centerpiece morphing **Liquid Glass Power Orb**: tapping starts/stops the shake detection service; also offers a quick manual torch toggle chip. Glows warm amber-gold when the flashlight is ON and cool ice-blue when armed.
     - **Live Shake Meter**: real-time spring-animated meter driven by filtered accelerometer magnitude and threshold marker so users can test shake intensity right on Home.
  3. **Settings Screen**:
     - Grouped translucent glass cards covering Gesture Mode (Double-Chop vs Single Shake), Shake Sensitivity (1–10 glass slider + Low/Med/High badge), Cooldown Delay (0.5s–5.0s slider), Vibrate on Toggle switch, Pause During Calls switch, Start on Boot switch, Battery Saver Mode (toggle, sampling rate selector, battery % threshold), and Theme preference.
  4. **Battery & Permissions Screen**:
     - Live checklist cards showing granted/missing status for Camera, Notifications, Phone State, and Battery Optimization Exemption, each with a direct one-tap fix or system settings deep-link.
     - Expandable OEM Background Restriction Guide with tailored instructions for Xiaomi (MIUI/HyperOS), Oppo/Realme (ColorOS), Vivo (FuntouchOS), and Samsung (One UI).
  5. **Floating Glass Navigation Bar**:
     - Pill-shaped frosted bottom bar switching smoothly between Home, Settings, and Battery & Permissions, respecting `WindowInsets.navigationBars`.

- **Visual Identity & Theme (Liquid Glass)**:
  - *Aesthetic Direction*: Tactile iOS 26/27-inspired "Liquid Glass" layered atop Material 3 semantics—translucent frosted panels floating over a slowly breathing aurora mesh backdrop.
  - *Color Palette & Mood*:
    - **Dark Mode**: Deep midnight navy backdrop (`#060B18`) with drifting sapphire (`#1D4ED8`), indigo-violet (`#6D28D9`), and cyan-teal (`#0D9488`) blurred gradient orbs; frosted glass fills (`Color.White.copy(alpha = 0.08f–0.14f)`); warm amber torch glow (`#FBBF24` / `#F59E0B`).
    - **Light Mode**: Soft glacial mist backdrop (`#EEF4FF`) with pastel sky (`#93C5FD`), lavender (`#C4B5FD`), and mint (`#99F6E4`) aurora orbs; crisp milky glass fills (`Color.White.copy(alpha = 0.52f–0.68f)`) with deep slate ink typography (`#0F172A`).
  - *Glass Craft & Borders*: True API 31+ `Modifier.blur` on background aurora layers and inner glow haloes, paired with 1.dp diagonal specular borders (bright white highlight top-left fading to subtle translucency bottom-right), soft inner sheen, and `24.dp`–`32.dp` rounded corners.
  - *Typography & Hierarchy*: Local bundled **Inter** font family (`res/font/inter.ttf` via `font-util`) with clean geometric tabular numbers (`tnum`) for sensitivity, cooldown seconds, and accelerometer telemetry.

- **Interactive Feedback & Motion**:
  - **Tilt-Reactive Specular Reflection**: Subscribes lightly while the app UI is foregrounded to device gravity tilt to shift the specular highlight angle and subtle orb parallax.
  - **Micro-Interactions**: Spring-physics scale bounce (`spring(dampingRatio = 0.65f, stiffness = 420f)`) on the central orb, glowing slider thumbs, pill-shaped animated toggles, and haptic confirmation pulses (`VibratorManager`).

---

### 3. Key Product Decisions & Trade-Offs

- **Signal Processing (High-Pass Filter + Double-Chop State Machine)**:
  - *Chosen Approach*: Apply a low-pass gravity estimator ($\alpha = 0.8$) subtracted from raw `TYPE_ACCELEROMETER` readings to isolate linear acceleration, then detect either two acceleration peaks within a 650ms window (Double-Chop default) or a single high-magnitude peak (Single Shake mode), gated by the user's cooldown timer.
  - *Why*: Eliminates static gravity bias and drastically reduces false triggers when setting the phone down or walking with it in a pocket.
  - *Alternatives Considered*: Raw acceleration magnitude threshold; rejected due to frequent pocket triggers.
- **Foreground Service Type (`specialUse`) & Safe Boot Handling**:
  - *Chosen Approach*: Declare `foregroundServiceType="specialUse"` with the required `PROPERTY_SPECIAL_USE_FGS_SUBTYPE` manifest metadata, use `START_STICKY`, and wrap `BOOT_COMPLETED` service starts in Android 12+/15+ exception handling with a fallback notification if restricted.
  - *Why*: Android 15 prohibits launching `camera`-typed foreground services from `BOOT_COMPLETED`, whereas `CameraManager.setTorchMode()` does not require a `camera` FGS type and `specialUse` is designed for persistent sensor utilities.
- **Settings Persistence (Jetpack DataStore Preferences)**:
  - *Chosen Approach*: Reactive `Preferences DataStore` exposed as a `Flow<ShakeSettings>` singleton via Hilt.
  - *Why*: Lightweight, coroutine-native, atomic writes shared seamlessly between the Compose UI and the background `ShakeService` process lifecycle without Room/SQL overhead.
- **Power Efficiency**:
  - *Chosen Approach*: Configurable sampling (`SENSOR_DELAY_NORMAL` in Battery Saver vs `SENSOR_DELAY_UI` standard) with sensor event batching (`maxReportLatencyUs`), automatic pause during calls or below battery threshold, and a short-lived `PARTIAL_WAKE_LOCK` acquired only during the brief torch-toggle transaction and released immediately in `finally`.
  - *Why*: Keeps continuous background battery drain minimal while maintaining crisp responsiveness even when the screen is off.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌───────────────────────────────────────────────────────────────────────────┐
│                         UI LAYER (Jetpack Compose + M3)                   │
│  ┌─────────────┐  ┌─────────────┐  ┌──────────────────┐  ┌─────────────┐  │
│  │ Onboarding  │  │ HomeScreen  │  │  SettingsScreen  │  │  Battery &  │  │
│  │  (3 Pages)  │  │ (Orb+Meter) │  │  (Glass Cards)   │  │ Permissions │  │
│  └──────┬──────┘  └──────┬──────┘  └────────┬─────────┘  └──────┬──────┘  │
│         └────────────────┴──────────────────┴───────────────────┘         │
│                                     │                                     │
│                         MainViewModel (@HiltViewModel)                    │
│                 StateFlow<MainUiState> + Live Telemetry Flow              │
└──────────────────────────┬─────────────────────────────┬──────────────────┘
                           │                             │
                           ▼                             ▼
┌────────────────────────────────────┐   ┌──────────────────────────────────┐
│     DATA & PREFERENCES LAYER       │   │     SYSTEM & SERVICE LAYER       │
│  ┌──────────────────────────────┐  │   │  ┌────────────────────────────┐  │
│  │  SettingsRepository          │  │   │  │       ShakeService         │  │
│  │  (Jetpack DataStore Flow)    │◄─┼───┼──┤  (Foreground: specialUse)  │  │
│  └──────────────────────────────┘  │   │  └─┬──────┬──────┬──────┬─────┘  │
│                                    │   │    │      │      │      │        │
│  ┌──────────────────────────────┐  │   │    ▼      ▼      ▼      ▼        │
│  │  ServiceStateBus (Singleton) │◄─┼───┼─ Shake  Torch  Vibra-  Call &    │
│  │  - isServiceRunning          │  │   │  Detec- Ctrl   tion    Battery   │
│  │  - isTorchOn                 │  │   │  tor                   Monitors  │
│  │  - liveShakeIntensity        │  │   └────▲─────────────────────────────┘
│  │  - pauseReason               │  │        │
│  └──────────────────────────────┘  │   ┌────┴─────────────────────────────┐
└────────────────────────────────────┘   │  BootReceiver (BOOT_COMPLETED)   │
                                         └──────────────────────────────────┘
```

- **Data Model & State**:
  - `ShakeSettings`: `sensitivity` (1..10, default 6), `gestureMode` (`DOUBLE_CHOP` | `SINGLE_SHAKE`), `cooldownMillis` (500..5000, default 1500), `startOnBoot` (Boolean), `vibrateOnToggle` (Boolean), `pauseDuringCalls` (Boolean), `batterySaverEnabled` (Boolean), `batteryThresholdPercent` (Int, default 15), `samplingRate` (`NORMAL` | `UI`), `themeMode` (`SYSTEM` | `DARK` | `LIGHT`), `onboardingCompleted` (Boolean).
  - `PauseReason` (sealed/enum): `NONE`, `IN_CALL`, `LOW_BATTERY`, `NO_FLASH_HARDWARE`.
  - `PermissionStatusSnapshot`: `cameraGranted`, `notificationsGranted`, `phoneStateGranted`, `ignoringBatteryOptimizations`, `hasFlashUnit`.

- **Interactive Component & State Mapping**:
  - **Central Glass Toggle Orb**: Dispatches `toggleService()` -> starts or stops `ShakeService` via `ContextCompat.startForegroundService` / stop Intent; reacts to `ServiceStateBus.isServiceRunning` and `isTorchOn` for color & glow morphing.
  - **Manual Torch Chip**: Calls `FlashlightController.toggleTorch()` directly for instant manual verification.
  - **Live Shake Meter**: Collects `ServiceStateBus.liveMagnitude` (or foreground `ShakeDetector` preview stream when service is stopped) so the user can test sensitivity thresholds live on Home even before arming the background service.
  - **Settings Controls**: Every slider and pill switch calls `MainViewModel` update methods -> persisted immediately to `DataStore` -> `ShakeService` collects `SettingsRepository.settingsFlow` and reconfigures sensor delay, threshold, call monitor, and battery monitor dynamically without restarting the service.
  - **Persistent Notification**: Displays current torch/listening state with a `PendingIntent` "Stop" action routed to `ShakeService` (`ACTION_STOP_SERVICE`) and tap-to-open `MainActivity`.
  - **Permissions & Battery Cards**: Launch runtime `ActivityResultContracts.RequestPermission` / `RequestMultiplePermissions` and `Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` / App Info fallback, refreshing status automatically on `ON_RESUME`.

- **Key Sequences**:
  - **Shake Trigger Flow**: `Accelerometer Event` -> `ShakeDetector` (low-pass/high-pass + chop/single peak logic) -> checks `pauseReason == NONE` and `elapsed >= cooldownMillis` -> acquires short `PARTIAL_WAKE_LOCK` -> `FlashlightController.toggleTorch()` -> `TorchCallback` updates `ServiceStateBus.isTorchOn` -> `VibrationHelper` plays 1 pulse (ON) or 2 pulses (OFF) -> updates notification -> releases wake lock in `finally`.
  - **Reboot Flow**: `BootReceiver.onReceive(ACTION_BOOT_COMPLETED)` -> reads `SettingsRepository` (`goAsync()`) -> if `startOnBoot == true`, starts `ShakeService` safely inside `try/catch`.
